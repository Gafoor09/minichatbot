import random

responses={
    "hi":["Hello! How can I assist you today?","Hi there! What can I do for you?","Greetings! How may I help you?"],
    "how are you":["I'm just a program, but thanks for asking! How can I help you?","Doing great! How about you?","I'm here to assist you! What do you need?"],
    "what is your name":["I'm ChatBot, your virtual assistant.","You can call me ChatBot.","I'm known as ChatBot."],
    "bye":["Goodbye! Have a great day!","See you later!","Take care!"]  
}
def chatbot_response(user_input):
    user_input = user_input.lower()
    for key in responses:
        if key in user_input:
            return random.choice(responses[key])
    return "I'm sorry, I don't understand. Can you please rephrase?"

print("Welcome to ChatBot! Type 'exit' to end the conversation.")
while True:
    user_input = input("You: ")
    if user_input.lower() == 'exit':
        print("ChatBot: Goodbye! Have a great day!")
        break
    response = chatbot_response(user_input)
    print("ChatBot:", response)
